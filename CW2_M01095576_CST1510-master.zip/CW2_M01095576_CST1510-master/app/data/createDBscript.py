import dbHelper

conn = dbHelper.connect_database()
cursor = conn.cursor()
createTableScript = ''''''