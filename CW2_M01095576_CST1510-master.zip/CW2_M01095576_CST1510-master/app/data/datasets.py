import sqlite3


def load_csv_to_table(conn, csv_path, table_name):
    """
    Load a CSV file into a database table using pandas.

    TODO: Implement this function.

    Args:
        conn: Database connection
        csv_path: Path to CSV file
        table_name: Name of the target table+

    Returns:
        int: Number of rows loaded
    """
    # TODO: Check if CSV file exists

    # TODO: Read CSV using pandas.read_csv()

    # TODO: Use df.to_sql() to insert data
    # Parameters: name=table_name, con=conn, if_exists='append', index=False

    # TODO: Print success message and return row count

    pass

databaseLoc = 'Data/myTest.db'

conn = sqlite3.connect(databaseLoc)
cursor = conn.cursor()
insert_script = """
    insert into users(userane, role, password_hash)
        values('hamna', '12345', 'user')
"""

with open('Data/cyber_incidents.cvs') as cyber:
    i = 0
    for line in cyber.readlines():
        if i == 0:
            i+=1
            continue
        line = line.strip()