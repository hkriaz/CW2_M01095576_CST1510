import sqlite3
from pathlib import Path

DATA_DIR = Path("Data")
DB_PATH = DATA_DIR / "data"
